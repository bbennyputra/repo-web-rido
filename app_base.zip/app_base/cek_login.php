<?php
include "config/koneksi.php";

function anti_injection($data){
  $filter = mysql_real_escape_string(stripslashes(strip_tags(htmlspecialchars($data,ENT_QUOTES))));
  return $filter;
}

$username = anti_injection($_POST['username']);
$pass = anti_injection(md5($_POST['password']));

// pastikan username dan password adalah berupa huruf atau angka.
if (!ctype_alnum($username) OR !ctype_alnum($pass)){
  header('location:index.php');
}else{
		$login  = mysql_query("SELECT * FROM tb_user WHERE username='$username' AND password='$pass'");		
		$ketemu = mysql_num_rows($login);
		$data  = mysql_fetch_array($login);
	
	// Apabila username dan password ditemukan
	if ($ketemu > 0){
	  session_start();
	  include "timeout.php";
	  
	  $_SESSION['id_user'] = $data['id'];

	// session timeout

		timer();
		if($data['level']=="admin"){
	  	header("location:admin/media.php?page=dashboard");
	  }else {
	  	header("location:pimpinan/media.php?page=dashboard");
		}
	}else{
	  echo "<script>parent.location ='index.php?result=error';</script>";
	}
}
?>
