<?php
$_CONFIG['appname'] = "LTEBase";
$_CONFIG['owner'] = "Andre Oktora";
$_CONFIG['owneraddress'] = "Jl. Cipta Karya Ujung";
$_CONFIG['ownercity'] = "Kota. Pekanbaru, Riau, Indonesia";
$_CONFIG['ownerpostalcode'] = "-";
$_CONFIG['ownertelp'] = "0812 7597 4191";
$_CONFIG['ownerfax'] = "(0761) xxxxx";
//$_CONFIG['logo'] = "../images/logo.png";
$_CONFIG['syscolor'] = "#f7e82e";
$_CONFIG['tinggikop'] = 70;
?>