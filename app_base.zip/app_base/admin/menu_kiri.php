<ul class="sidebar-menu" data-widget="tree">
  <li class="header">MAIN NAVIGATION</li>
  <?php 
    $page = $_GET['page'];
      if ($page=="dashboard") {
        echo '<li class="active">
                <a href="?page=dashboard">
                  <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                </a>
              </li>
              <li>
                <a href="?page=user">
                  <i class="fa fa-plus"></i> <span>Data Pengguna</span>
                </a>
              </li>
              <li>
                <a href="?page=barang">
                  <i class="fa fa-plus"></i> <span>Data Barang</span>
                </a>
              </li>
              <li>
                <a href="?page=penjualan">
                  <i class="fa fa-plus"></i> <span>Data Penjualan</span>
                </a>
              </li>'; 
      }elseif ($page=="certificate" or $page=="certificate_edit" or $page="certificate_delete" or $page="certificate_update" ){
        echo '<li>
                <a href="?page=dashboard">
                  <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                </a>
              </li>
              <li class="active">
                <a href="?page=user">
                  <i class="fa fa-plus"></i> <span>Data Pengguna</span>
                </a>
              </li>
              <li class="active">
                <a href="?page=barang">
                  <i class="fa fa-plus"></i> <span>Data Barang</span>
                </a>
              </li>
              <li class="active">
                <a href="?page=penjualan">
                  <i class="fa fa-plus"></i> <span>Data Penjualan</span>
                </a>
              </li>'; }
  ?>
</ul>
