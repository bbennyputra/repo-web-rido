<html>
<!--SweetAlert Needed-->
<link rel="stylesheet" type="text/css" href="../alert/css/sweetalert.css">
<script src="../alert/js/sweetalert-dev.js"></script>
<script src="../alert/js/sweetjs.min"></script>
<!--End SweetAlert Needed-->
</body>

<div id="wraptambah">


<?php
include "../config/koneksi.php";
$tanggal = "$_POST[tgl_lahir]";

$tanggal = explode('/',$tanggal);
$tgl = $tanggal[2] .'-'. $tanggal[0] .'-'. $tanggal[1];

    $q = mysql_query("INSERT INTO tb_user (id, nama_user, tempat_lahir, tgl_lahir, alamat, telp, username, password, level) VALUES ('', '$_POST[nama]', '$_POST[tempat_lahir]', '$tgl' , '$_POST[alamat]', '$_POST[telp]', '$_POST[username]', md5('$_POST[username]'), '$_POST[level]')");
    
    if($q){
        echo '<script>
                    document.getElementById("wrap-tambah").innerHTML = 
                    swal({
                        title: "SUKSES",
                        text: "Data User Berhasil Ditambah",
                        type: "success",
                        showConfirmButton: false,
                        timer: 4000,   
                    },
                    function(){
                        window.location.href = "?page=user"
                    });
                </script>';
    } else {
        echo '<script>
                    document.getElementById("wrap-tambah").innerHTML = 
                    swal({
                        title: "GAGAL",
                        text: "Data User Gagal Ditambahkan",
                        type: "error",
                        showConfirmButton: false,
                        timer: 4000,   
                    },
                    function(){
                        window.location.href = "?page=user"
                    });
                </script>';     
    }
    
?>

</div>
</body>
</html>