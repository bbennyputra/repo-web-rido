<html>
<!--SweetAlert Needed-->
<link rel="stylesheet" type="text/css" href="../alert/css/sweetalert.css">
<script src="../alert/js/sweetalert-dev.js"></script>
<script src="../alert/js/sweetjs.min"></script>
<!--End SweetAlert Needed-->
</body>

<div id="wraptambah">

<!---------------------------------- HAPUS USER ---------------------------------->
<?php

		$hapus = $_GET['id'];
				$q = mysql_query("DELETE FROM tb_user WHERE id='$hapus'");
					 if($q){
		echo '<script>
                    document.getElementById("wrap-tambah").innerHTML = 
                    swal({
                        title: "SUKSES",
                        text: "Data User Berhasil Dihapus",
                        type: "success",
                        showConfirmButton: false,
                        timer: 4000,   
                    },
                    function(){
                         window.location.href = "?page=user"
                    });
                </script>';
	} else {
		echo '<script>
                    document.getElementById("wrap-tambah").innerHTML = 
                    swal({
                        title: "GAGAL",
                        text: "Data User Gagal Dihapus",
                        type: "error",
                        showConfirmButton: false,
                        timer: 4000,   
                    },
                    function(){
                        window.location.href = "?page=user"
                    });
                </script>';		
	}
	?>
<!---------------------------------- Akhir HAPUS USER ---------------------------------->
</div>
</body>
</html>