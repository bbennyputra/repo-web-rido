<html>
<!--SweetAlert Needed-->
<link rel="stylesheet" type="text/css" href="../alert/css/sweetalert.css">
<script src="../alert/js/sweetalert-dev.js"></script>
<script src="../alert/js/sweetjs.min"></script>
<!--End SweetAlert Needed-->
</body>

<div id="wraptambah">


<?php
include "../config/koneksi.php";

    $q = mysql_query("INSERT INTO tb_barang (kode_barang, nama_barang, jml_barang, satuan_barang, harga_barang, keterangan) 
        VALUES ('$_POST[kode_barang]', '$_POST[nama_barang]', '$_POST[jml_barang]', '$_POST[satuan_barang]', '$_POST[harga_barang]', '$_POST[keterangan]')");
    
    if($q){
        echo '<script>
                    document.getElementById("wrap-tambah").innerHTML = 
                    swal({
                        title: "SUKSES",
                        text: "Data Barang Berhasil Ditambah",
                        type: "success",
                        showConfirmButton: false,
                        timer: 4000,   
                    },
                    function(){
                        window.location.href = "?page=barang"
                    });
                </script>';
    } else {
        echo '<script>
                    document.getElementById("wrap-tambah").innerHTML = 
                    swal({
                        title: "GAGAL",
                        text: "Data Barang Gagal Ditambahkan",
                        type: "error",
                        showConfirmButton: false,
                        timer: 4000,   
                    },
                    function(){
                        window.location.href = "?page=barang"
                    });
                </script>';     
    }
    
?>

</div>
</body>
</html>