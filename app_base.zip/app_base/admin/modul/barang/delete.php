<html>
<!--SweetAlert Needed-->
<link rel="stylesheet" type="text/css" href="../alert/css/sweetalert.css">
<script src="../alert/js/sweetalert-dev.js"></script>
<script src="../alert/js/sweetjs.min"></script>
<!--End SweetAlert Needed-->
</body>

<div id="wraptambah">

<!---------------------------------- HAPUS BARANG ---------------------------------->
<?php

		$hapus = $_GET['id'];
				$q = mysql_query("DELETE FROM tb_barang WHERE kode_barang='$hapus'");
					 if($q){
		echo '<script>
                    document.getElementById("wrap-tambah").innerHTML = 
                    swal({
                        title: "SUKSES",
                        text: "Data Barang Berhasil Dihapus",
                        type: "success",
                        showConfirmButton: false,
                        timer: 4000,   
                    },
                    function(){
                         window.location.href = "?page=barang"
                    });
                </script>';
	} else {
		echo '<script>
                    document.getElementById("wrap-tambah").innerHTML = 
                    swal({
                        title: "GAGAL",
                        text: "Data Barang Gagal Dihapus",
                        type: "error",
                        showConfirmButton: false,
                        timer: 4000,   
                    },
                    function(){
                        window.location.href = "?page=barang"
                    });
                </script>';		
	}
	?>
<!---------------------------------- Akhir HAPUS BARANG ---------------------------------->
</div>
</body>
</html>