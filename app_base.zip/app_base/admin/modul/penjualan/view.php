    <section class="content-header">
      <h1>
        penjualan
        <small>Data penjualan</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="?page=dashboard"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li><a href="?page=penjualan">penjualan</a></li>
        <li class="active">Here</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <!-- /.box -->
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Data penjualan</h3>
              <a href="#" type="button" style="margin-left: 81%" class="btn btn-primary btn-xs" data-toggle="modal" data-target="#modal-default">
                <span><i class='fa fa-plus'></i> Tambah penjualan</span>
              </a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th width="10">No</th>
                  <th width="150">Kode Transaksi</th>
                  <th width="150">Tanggal penjualan</th>
                  <th width="100">Kode barang</th>
                  <th width="120">Nama barang</th>
                  <th width="75">Jumlah barang</th>
                  <th width="10">Satuan barang</th>
                  <th width="75">Harga barang</th>
                  <th width="10">Keterangan</th>
                </tr>
                </thead>
                <tbody>
                  <?php
                   
                    $qry = mysql_query("SELECT * FROM tb_penjualan Order by kode_transaksi Asc");
                      while ($penjualan = mysql_fetch_array($qry)){
                  ?>
                <tr>
                  <?php
                      $no++;
                      echo "
                      <td><center>$no</center></td>
                      <td>$penjualan[kode_transaksi]</td>
                      <td>".getTglIndo($penjualan[tgl_penjualan])."</td>
                      <td>$penjualan[kode_barang]</td>
                      <td>$penjualan[nama_barang]</td>
                      <td>$penjualan[jml_barang]</td>
                      <td>$penjualan[satuan_barang]</td>
                      <td>$penjualan[harga_barang]</td>
                      <td>$penjualan[keterangan]</td>
                      <td>
                        <center>
                          <a href='#myModal' id='custId' data-toggle='modal' data-id=".$penjualan['id']." class='tooltip-success' data-rel='tooltip' title='Edit'>
                               <span style='color:green'><i class='fa fa-edit'></i></span> 
                          </a>
                          ||
                          <a href='media.php?page=penjualan_delete&id=$penjualan[kode_transaksi]' onclick='return qh();' class='tooltip-error' data-rel='tooltip' title='Delete'>
                              <span style='color:red'><i class='fa fa-trash'></i></span>
                          </a>
                        </center>
                      </td>";
                      ?>
                </tr>
                  <?php
                    }
                  ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!------- Modal Tambah penjualan ------>
    <div class="modal fade" id="modal-default" style="display: none;">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
              <h4 class="modal-title" id="myModalLabel">Tambah penjualan</h4>
          </div>
          <div class="modal-body">
            <form action="?page=penjualan_save" role="form" name="modal_popup" onSubmit="return validasi()" enctype="multipart/form-data" method="POST">      
             <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-info"></i></span>
                <input type="text" name="kode_transaksi" class="form-control" placeholder="Kode Transaksi" required />
              </div>
              <br />

            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-info"></i></span>
                <input type="date" name="tgl_penjualan" class="form-control" placeholder="MM/DD/YYY" required />
              </div>
              <br />

            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-info"></i></span>
                <input type="text" name="kode_barang" class="form-control" placeholder="Kode Barang" required />
              </div>
              <br />

            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-info"></i></span>
                <input type="text" name="nama_barang" class="form-control" placeholder="Nama Barang" required />
              </div>
              <br />

            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-info"></i></span>
                <input type="number" name="jml_barang" class="form-control" placeholder="Jumlah Barang" required />
              </div>
              <br />

            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-info"></i></span>
                <input type="text" name="satuan_barang" class="form-control" placeholder="Satuan barang" required />
              </div>
              <br />

             <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-info"></i></span>
                <input type="number" name="harga_barang" class="form-control" placeholder="Harga Barang" required />
              </div>
              <br />

            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-info"></i></span>
                <input type="text" name="keterangan" class="form-control" placeholder="Keterangan" required />
              </div>
              <br />
             
              <div class="modal-footer">
                <button class="btn btn-primary" type="submit"> Save</button>
                <button type="reset" class="btn btn-danger"  data-dismiss="modal" aria-hidden="true"> Cancel</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    <!------- Akhir Modal Tambah penjualan ------>

    <!-- Modal Edit penjualan -->
        <div class="modal fade" id="myModal" role="dialog">
          <div class="modal-dialog" role="document">
              <div class="modal-content">
                  <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                      <h4 class="modal-title">Edit Data penjualan</h4>
                  </div>
                  <div class="modal-body">
                      <div class="fetched-data"></div>
                  </div>
              </div>
          </div>
        </div>
      <!-- Modal Edit Pelanggan -->
<script type="text/javascript">
    $(document).ready(function(){
        $('#myModal').on('show.bs.modal', function (e) {
            var rowid = $(e.relatedTarget).data('id');
            //menggunakan fungsi ajax untuk pengambilan data
            $.ajax({
                type : 'post',
                url : 'modul/penjualan/edit.php',
                data :  'rowid='+ rowid,
                success : function(data){
                $('.fetched-data').html(data);//menampilkan data ke dalam modal
                }
            });
         });
    });
</script>