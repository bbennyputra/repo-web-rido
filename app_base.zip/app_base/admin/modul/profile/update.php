<html>
<!--SweetAlert Needed-->
<link rel="stylesheet" type="text/css" href="../alert/css/sweetalert.css">
<script src="../alert/js/sweetalert-dev.js"></script>
<script src="../alert/js/sweetjs.min"></script>
<!--End SweetAlert Needed-->
</body>

<div id="wraptambah">


<?php
  include "../config/koneksi.php";
        $tanggal = "$_POST[tgl_lahir]";
        $tanggal = explode('/',$tanggal);
        $tgl = $tanggal[2] .'-'. $tanggal[0] .'-'. $tanggal[1];
        if (!empty($_POST[password])){

            $xp = md5($_POST[password]);
            $q = mysql_query("UPDATE tb_user SET nama_user='$_POST[nama]', tempat_lahir='$_POST[tempat_lahir]', tgl_lahir='$tgl', alamat='$_POST[alamat]', telp='$_POST[telp]', username='$_POST[username]', password='$xp' where id='$_POST[id]' ");
        }else{
            $q = mysql_query("UPDATE tb_user SET nama_user='$_POST[nama]', tempat_lahir='$_POST[tempat_lahir]', tgl_lahir='$tgl', alamat='$_POST[alamat]', telp='$_POST[telp]', username='$_POST[username]' where id='$_POST[id]' ");
        }      
    if($q){
		echo '<script>
                    document.getElementById("wrap-tambah").innerHTML = 
                    swal({
                        title: "SUKSES",
                        text: "Data Anda Berhasil Diupdate",
                        type: "success",
                        showConfirmButton: false,
                        timer: 4000,   
                    },
                    function(){
                         window.location.href = "?page=profile"
                    });
                </script>';
	} else {
		echo '<script>
                    document.getElementById("wrap-tambah").innerHTML = 
                    swal({
                        title: "GAGAL",
                        text: "Data Anda Gagal Diupdate",
                        type: "error",
                        showConfirmButton: false,
                        timer: 4000,   
                    },
                    function(){
                        window.location.href = "?page=profile"
                    });
                </script>';		
	}
    
?>

</div>
</body>
</html>