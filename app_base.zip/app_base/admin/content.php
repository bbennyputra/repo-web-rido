<?php
if ($_GET[page]=='dashboard'){
	include 'dashbord.php';

/////////////////// Awal Profile ///////////////////
}elseif($_GET[page]=='profile'){
	include 'modul/profile/profile.php';
}elseif($_GET[page]=='profile_update'){
	include 'modul/profile/update.php';
/////////////////// Awal Profile ///////////////////


//////////////////// Awal Barang/////////////////
}elseif($_GET[page]=='barang'){
	include 'modul/barang/view.php';
}elseif($_GET[page]=='barang_save'){
	include 'modul/barang/save.php';
}elseif($_GET[page]=='barang_delete'){
	include 'modul/barang/delete.php';
//////////////////// Akhir Barang ///////////////

//////////////////// Awal Penjualan /////////////
}elseif($_GET[page]=='penjualan'){
	include 'modul/penjualan/view.php';
}elseif($_GET[page]=='penjualan_save'){
	include 'modul/penjualan/save.php';
}elseif($_GET[page]=='penjualan_delete'){
	include 'modul/penjualan/delete.php';


/////////////////// Awal User ///////////////////

}elseif($_GET[page]=='user'){
	include 'modul/user/view.php';
}elseif($_GET[page]=='user_save'){
	include 'modul/user/save.php';
}elseif($_GET[page]=='user_update'){
	include 'modul/user/update.php';
}elseif($_GET[page]=='user_delete'){
	include 'modul/user/delete.php';
	
/////////////////// Akhir User ///////////////////

}else{
	include 'eror.php';
}
?>